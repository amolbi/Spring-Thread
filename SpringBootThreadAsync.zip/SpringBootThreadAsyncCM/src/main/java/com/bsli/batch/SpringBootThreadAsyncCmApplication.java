package com.bsli.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootThreadAsyncCmApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootThreadAsyncCmApplication.class, args);
	}

}
