package com.bsli.batch.cotroller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bsli.batch.service.ThreadService;

@RestController
@RequestMapping("/api/thread")
public class ThreadController 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ThreadController.class);

	@Autowired
	private ThreadService threadService;

	@GetMapping("/checkThreads")
	// consumes={MediaType.APPLICATION_JSON_VALUE},
	// produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody CompletableFuture<ResponseEntity> checkThreadsMethod() {
		ArrayList<Integer> list = new ArrayList<>();
		for (int i = 0; i <= 25; i++) {
			list.add(i);
		}
		System.out.println("CarController.checkThreadsMethod()" + list.size());

		ArrayList<CompletableFuture<ArrayList<Integer>>> responseList = new ArrayList<CompletableFuture<ArrayList<Integer>>>();

		for (Integer in : list) {
			responseList.add(threadService.checkTreads(in));
		}

		CompletableFuture<ArrayList<CompletableFuture<ArrayList<Integer>>>> aa = CompletableFuture
				.completedFuture(responseList);
		return aa.<ResponseEntity>thenApply(ResponseEntity::ok);
	}

}
