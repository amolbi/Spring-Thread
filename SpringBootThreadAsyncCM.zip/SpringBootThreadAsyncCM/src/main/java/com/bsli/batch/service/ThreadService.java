package com.bsli.batch.service;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;


@Service
public class ThreadService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ThreadService.class);
	
	 @Async
	    public CompletableFuture<ArrayList<Integer>> checkTreads(Integer inputInt)
	    {
//	    	System.out.println("CarService.checkTreads()"+inputInt);
	    	LOGGER.info("Processing-"+ inputInt);
	    	ArrayList<Integer> listToReturn = new ArrayList<>();	
	    	
	    	listToReturn.add(inputInt);
	    	
	    	return CompletableFuture.completedFuture(listToReturn);
	    }

}
